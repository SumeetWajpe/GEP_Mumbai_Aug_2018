var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var str = "Hello World !"; // type inference
console.log(str);
var x; // type annotation !
x = 100;
var boolVar;
var s;
var anyTypeVar;
anyTypeVar = 1000;
anyTypeVar = "Hello !";
anyTypeVar = { name: 'GEP' }; // Literal Syntax !
anyTypeVar = [10, 20, 30, 40]; // Arrays !
var cars = ['BMW', 'AUDI'];
var moreCars = new Array('TATA', 'MAHINDRA');
var allCars = cars.concat(moreCars); // Spread Operator !
// for
// for-in --> index
// for-of --> element
for (var _i = 0, allCars_1 = allCars; _i < allCars_1.length; _i++) {
    var c = allCars_1[_i];
    console.log(c);
}
function Addition(x, y) {
    if (x < 0) {
        return 'The value of x should be > 0';
    }
    return x + y;
}
var result = Addition(10, 20);
// Blocked Scoped Variables
//1. Global
// 2. Function
if (true) {
    var blockScopedVar = 100;
    // 100 lines of code !
    //let blockScopedVar = 1000;
}
//  console.log(blockScopedVar); // Error ! Not accessible !
var PI = 3.14;
// PI =3.1465; // Error !
//Enumerations !
var Designation;
(function (Designation) {
    Designation[Designation["Developer"] = 0] = "Developer";
    Designation[Designation["Trainer"] = 1] = "Trainer";
    Designation[Designation["Tester"] = 2] = "Tester";
    Designation[Designation["TeamLead"] = 3] = "TeamLead";
})(Designation || (Designation = {}));
var desg;
desg = Designation.Trainer;
console.log(desg); // number
console.log(Designation[desg]); // string representation !
var Categories;
(function (Categories) {
    Categories[Categories["Inspirational"] = 0] = "Inspirational";
    Categories[Categories["Autobiography"] = 1] = "Autobiography";
    Categories[Categories["Fiction"] = 2] = "Fiction";
    Categories[Categories["Comic"] = 3] = "Comic";
})(Categories || (Categories = {}));
function GetAllBooks() {
    var books = [
        { title: 'Mrutyunjay', author: 'Ranjit Desai', price: 600, stockAvailable: true, category: Categories.Fiction },
        { title: 'Playing It My Way', author: 'Sachin Tendulkar', price: 1000, stockAvailable: false, category: Categories.Autobiography },
        { title: 'Radhey', author: 'Ranjit Desai', price: 400, stockAvailable: true, category: Categories.Fiction },
        { title: 'I am Malala', author: 'Malala', price: 400, stockAvailable: false, category: Categories.Autobiography },
        { title: 'Wings Of Fire', author: 'Dr. APJ Abdul Kalam', price: 300, stockAvailable: true, category: Categories.Autobiography }
    ];
    return books;
}
var allBooks = GetAllBooks();
for (var _a = 0, allBooks_1 = allBooks; _a < allBooks_1.length; _a++) {
    var book = allBooks_1[_a];
    console.log(book.title + " is of Rs." + book.price);
}
//var company:any = {name:'GEP',location:'Airoli'}
function GetBooksByCategory(inputCategory) {
    var bookswithCategory = [];
    for (var _i = 0, allBooks_2 = allBooks; _i < allBooks_2.length; _i++) {
        var b = allBooks_2[_i];
        if (b.category == inputCategory) {
            bookswithCategory.push(b.title);
        }
    }
    return bookswithCategory;
}
var autobiographyBooks = GetBooksByCategory(Categories.Autobiography);
for (var _b = 0, autobiographyBooks_1 = autobiographyBooks; _b < autobiographyBooks_1.length; _b++) {
    var b = autobiographyBooks_1[_b];
    console.log(b);
}
// Functions
// function Square(x){
//     return x * x;
// }
// Function as an expression !
// var Square = function(x){
//     return x*x;
// }
// Arrow Functions
var Square = function (x) {
    return x * x;
};
// OR
//var Square = x =>  x*x;
autobiographyBooks.forEach(function (b) {
    console.log(b);
});
// OR
autobiographyBooks.forEach(function (b) { return console.log(b); });
function Emp() {
    var _this = this;
    this.Salary = 200000;
    setTimeout(function () {
        console.log(_this.Salary);
    }, 2000);
}
// Parameters
//1. Optional
// function PrintBook(author?:string,noOfPages?:number,publication?:string):void{  
//         console.log(author,noOfPages,publication)
// }
// 2. Default
function PrintBook(author, noOfPages, publication) {
    if (author === void 0) { author = "Unknown"; }
    if (noOfPages === void 0) { noOfPages = 0; }
    if (publication === void 0) { publication = "Unknown"; }
    console.log(author, noOfPages, publication);
}
PrintBook();
PrintBook("SK Sharma", 200);
// interface IEmp{
//     name:string;
//     salary:number;
//     getSalary():number;
// }
// var e:IEmp = {name:'Rajesh',salary:400000,getSalary:function(){
//     return 200000;
// }}
//Classes
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 200; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.Accelerate = function () {
        return (this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
//  var carObj = new Car("i30",300);
//  carObj.Accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(n, s, sub, visible) {
        var _this = _super.call(this, n, s) || this;
        _this.canBeInvisible = visible;
        _this.canSubmerge = sub;
        return _this;
    }
    JamesBondCar.prototype.Accelerate = function () {
        return _super.prototype.Accelerate.call(this) + " Can It Submerge ?" + this.canSubmerge;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Houston", 500, true, true);
console.log(jbc.Accelerate());
var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.getSalary = function () {
        return this.salary;
    };
    return Employee;
}());
//creates member variables and initializes them !
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(id, name, speed) {
        this.id = id;
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());
var e = new EnhancedCar(1, "i20", 200);
