var str = "Hello World !";// type inference
console.log(str);

var x:number; // type annotation !
x = 100;

var boolVar:boolean;
var s:string;

var anyTypeVar:any;
anyTypeVar = 1000;
anyTypeVar = "Hello !";
anyTypeVar = {name:'GEP'};// Literal Syntax !
anyTypeVar = [10,20,30,40];// Arrays !

var cars:string[] = ['BMW','AUDI'];
 var moreCars:Array<string> = new Array<string>('TATA','MAHINDRA')

 var allCars = [...cars,...moreCars]; // Spread Operator !

 // for
 // for-in --> index
// for-of --> element

 for(var c of allCars){
     console.log(c); 
 }

 function Addition(x:number,y:number):number | string {
    
    if(x<0){
        return 'The value of x should be > 0';
    }
    
    return x + y;
 }

 var result:number |  string = Addition(10,20);



 // Blocked Scoped Variables
 //1. Global
 // 2. Function

 if(true){
     let blockScopedVar = 100;
     // 100 lines of code !
     //let blockScopedVar = 1000;
 }
//  console.log(blockScopedVar); // Error ! Not accessible !

const PI = 3.14;
// PI =3.1465; // Error !

//Enumerations !

enum Designation{
    Developer,
    Trainer,
    Tester,
    TeamLead
}

let desg:Designation;

desg = Designation.Trainer;
console.log(desg); // number
console.log(Designation[desg]); // string representation !

enum Categories{
    Inspirational,
    Autobiography,
    Fiction,
    Comic
}

interface IBook{
    title:string;
    price:number;
    author:string;
    stockAvailable:boolean;
    category:Categories;
}

function GetAllBooks():IBook[]{
    let books:IBook[] = [
        {title:'Mrutyunjay',author:'Ranjit Desai',price:600,stockAvailable:true,category:Categories.Fiction},
        {title:'Playing It My Way',author:'Sachin Tendulkar',price:1000,stockAvailable:false,category:Categories.Autobiography},
        {title:'Radhey',author:'Ranjit Desai',price:400,stockAvailable:true,category:Categories.Fiction},
        {title:'I am Malala',author:'Malala',price:400,stockAvailable:false,category:Categories.Autobiography},
        {title:'Wings Of Fire',author:'Dr. APJ Abdul Kalam',price:300,stockAvailable:true,category:Categories.Autobiography}
    ]
        return books;
}
var allBooks:IBook[] = GetAllBooks();

for(let book of allBooks){
    console.log(book.title + " is of Rs." + book.price)
}

//var company:any = {name:'GEP',location:'Airoli'}

function GetBooksByCategory(inputCategory:Categories):string[]{
        let bookswithCategory:string[] = [];
            for (let b of allBooks) {
                    if(b.category == inputCategory){
                        bookswithCategory.push(b.title);
                    }
            }
                return bookswithCategory;
}
var autobiographyBooks:string[] = GetBooksByCategory(Categories.Autobiography)

for(let b of autobiographyBooks){
    console.log(b);
}

// Functions

// function Square(x){
//     return x * x;
// }

// Function as an expression !
// var Square = function(x){
//     return x*x;
// }

// Arrow Functions
var Square = (x:number):number => {
    return x * x;
}
// OR
//var Square = x =>  x*x;
autobiographyBooks.forEach(function(b){
        console.log(b)
});
// OR
autobiographyBooks.forEach(
    b =>  console.log(b)   
)

function Emp(){
    this.Salary = 200000;
    
setTimeout(()=>{
console.log(this.Salary)
},2000)
}

// Parameters
//1. Optional


// function PrintBook(author?:string,noOfPages?:number,publication?:string):void{  
//         console.log(author,noOfPages,publication)
// }

// 2. Default


function PrintBook(author:string="Unknown",noOfPages:number=0,publication:string="Unknown"):void{
    console.log(author,noOfPages,publication)
}

PrintBook();
PrintBook("SK Sharma",200)


// interface IEmp{
//     name:string;
//     salary:number;
//     getSalary():number;
// }

// var e:IEmp = {name:'Rajesh',salary:400000,getSalary:function(){
//     return 200000;
// }}

//Classes


 class Car{
     private id:number;
     name:string;
     speed:number;
    constructor(name:string="i20",speed:number=200){
            this.name = name;
            this.speed = speed;
    }
     Accelerate():string{
         return (this.name + " is running at " + this.speed + " kmph !")
     }
 }
//  var carObj = new Car("i30",300);
//  carObj.Accelerate();
class JamesBondCar extends Car{
        canSubmerge:boolean;
        canBeInvisible:boolean;
        constructor(n:string,s:number,sub:boolean,visible:boolean){
            super(n,s);
            this.canBeInvisible = visible;
            this.canSubmerge = sub;
        }
        Accelerate():string{
                return  super.Accelerate() + " Can It Submerge ?" + this.canSubmerge
        }
}
var jbc = new JamesBondCar("Houston",500,true,true);
console.log(jbc.Accelerate());

interface IPerson{
    name:string;
    age:number;
}

interface IEmp{
    salary:number;
    getSalary():number;
}

class Employee implements IPerson,IEmp{
    name:string;
    age:number;
    salary:number;
    getSalary():number{
            return this.salary;
    }
}

//creates member variables and initializes them !
class EnhancedCar{
        constructor(private id:number, public name:string,public speed:number){

        }

}


var e = new EnhancedCar(1,"i20",200);
