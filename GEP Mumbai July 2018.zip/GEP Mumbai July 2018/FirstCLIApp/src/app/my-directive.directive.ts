import { Directive, Renderer2, HostListener, ElementRef } from '@angular/core';


@Directive({
  selector: '[appMyDirective]'
})
export class MyDirectiveDirective {

  constructor(
      private refElement:ElementRef,
      private renderObj:Renderer2


  ) {  
  }
  ngOnInit(){  
  }


  @HostListener('click') OnClick(){
    var div = this.renderObj.createElement('div');
    var text = this.renderObj.createText("New Node !");
    this.renderObj.addClass(div,"divClass");
    this.renderObj.appendChild(div,text);
    this.renderObj.appendChild(this.refElement.nativeElement,div);
  }

}
