import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit,OnChanges {


  @Input() name:string="";

  constructor() {
    console.log('Within Constructor ! Name : ' + this.name)
   }

   ngOnChanges(){
    console.log('Within ngOnChanges ! Name : '+ this.name);
   }



  ngOnInit() {
    console.log('Within ngOnInit ! Name : '+ this.name)
     
  }

  ngOnDestroy(){

  }

}
