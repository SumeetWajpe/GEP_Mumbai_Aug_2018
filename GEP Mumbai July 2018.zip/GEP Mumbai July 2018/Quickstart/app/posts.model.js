"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Posts = (function () {
    function Posts(id, userId, title, body) {
        this.id = id;
        this.userId = userId;
        this.title = title;
        this.body = body;
    }
    return Posts;
}());
exports.Posts = Posts;
//# sourceMappingURL=posts.model.js.map