"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var course_model_1 = require("./course.model");
var AppComponent = (function () {
    function AppComponent() {
        this.imageUrl = "https://cdn-images-1.medium.com/max/588/1*15CYVZdpsxir8KLdxEZytg.png";
        this.courses = [
            new course_model_1.Course("React", '3 Days'),
            new course_model_1.Course("Redux", '2 Days'),
            new course_model_1.Course("Node", '3 Days')
        ];
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n\n  <a routerLink=\"/posts\" class=\"btn btn-primary\">Posts</a>\n  <a routerLink=\"/cart\" class=\"btn btn-primary\">ShoppingCart</a>\n\n  <router-outlet></router-outlet>\n  \n  "
        //template:'<newcourse></newcourse><newcourse></newcourse>'
        // templateUrl:`./app/app.template.html`
        //template:`<shoppingcart></shoppingcart>`  
        ,
        styleUrls: ["./app/course.style.css"]
        //   template: `<course name="ReactJS"></course>
        //   <course name="NodeJS"></course>
        //   <course name="Backbone"></course>
        //   <course></course>
        //  `,
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map