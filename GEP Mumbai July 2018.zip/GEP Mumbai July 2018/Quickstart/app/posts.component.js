"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var posts_service_1 = require("./posts.service");
var PostsComponent = (function () {
    // srcArr:number[] = [1,2,3,4,5];
    // private myArr:Observable<number> = Observable.from(this.srcArr) 
    // using callbacks
    // constructor(private postsServObj:PostsService){
    //         this.postsServObj.getPosts((resp:any)=>{
    //                 console.log('within component');
    //                 this.allposts = resp;
    //         });
    // }
    // using promises
    // constructor(private postsServObj:PostsService){
    //  let aPromise =   this.postsServObj.getPosts();
    //  aPromise.then(
    //      (responseFromService)=>{
    //          this.allposts =responseFromService.json();
    //      },
    //      (err)=>{
    //          console.log('rejected')
    //      }
    //  )
    //}
    //using Observables
    function PostsComponent(postsServObj) {
        var _this = this;
        this.postsServObj = postsServObj;
        this.allposts = [];
        this.postsServObj.getPosts().subscribe(function (res) {
            _this.allposts = res;
            localStorage["posts"] = JSON.stringify(res);
        });
    }
    return PostsComponent;
}());
PostsComponent = __decorate([
    core_1.Component({
        selector: 'posts',
        template: "<h1> Posts </h1>\n    <ul>\n        <li *ngFor=\"let p of allposts\" postStyle bgcolor=\"lightgreen\">\n       <a routerLink=\"/post/{{p.id}}\"> {{p.title}} </a>\n        </li>\n    </ul>\n   ",
        providers: [posts_service_1.PostsService]
    }),
    __metadata("design:paramtypes", [posts_service_1.PostsService])
], PostsComponent);
exports.PostsComponent = PostsComponent;
//# sourceMappingURL=posts.component.js.map