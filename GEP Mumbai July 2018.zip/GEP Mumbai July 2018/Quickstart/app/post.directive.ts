import { Directive, ElementRef, OnInit, Input, HostListener } from "@angular/core";

@Directive({
    selector:`[postStyle]`,
})
export class PostDirective implements OnInit{

    @Input('bgcolor') bgColor:string="orange";

        constructor(private refElem:ElementRef){
        }
        ngOnInit(){
                this.refElem.nativeElement.style.border = "2px solid red";
                this.refElem.nativeElement.style.backgroundColor = this.bgColor;
                this.refElem.nativeElement.style.margin = "10px"; 
                this.refElem.nativeElement.style.padding = "10px"; 
                this.refElem.nativeElement.style.borderRadius = "10px" ;
        }

      @HostListener('mouseenter')   OnMouseOver(){
        this.refElem.nativeElement.style.backgroundColor = "orange";
        }

        @HostListener('mouseleave') OnMouseOut(){
            this.refElem.nativeElement.style.backgroundColor = this.bgColor;
        }
}