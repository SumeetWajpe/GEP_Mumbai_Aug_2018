import { PipeTransform, Pipe } from "@angular/core";

@Pipe({
    name:'qty'
})
export class QuantityPipe implements PipeTransform{
            transform(inputValue:number,theArgs:string){
                        return inputValue +" " + theArgs;
                }
}