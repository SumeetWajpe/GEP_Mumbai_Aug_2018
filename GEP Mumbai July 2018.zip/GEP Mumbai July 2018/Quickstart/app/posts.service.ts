
import {Http} from '@angular/http';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';

import  'rxjs/add/operator/toPromise';
import  'rxjs/add/operator/map';

import { Posts } from './posts.model';
// import {toPromise} from 'rxjs'; // angular 5.0

@Injectable()
export class PostsService{



    // Injecting Http Service instance 
    constructor(private httpServObj:Http){
        
    }

    //using observables
    // getPosts(callbackfunc:any){
    //     // make ajaxified request here !
    //     // use Http Service here !
    //     this.httpServObj
    //     .get('https://jsonplaceholder.typicode.com/posts')
    //     .subscribe(function(response){
    //         callbackfunc(response.json());
    //     })
    // }

    // using Promises
    // getPosts(){
    //     // make ajaxified request here !
    //     // use Http Service here !
    //   return  this.httpServObj
    //     .get('https://jsonplaceholder.typicode.com/posts')
    //     .toPromise();
        
    // }


    // returning an Observable
    // getPosts():Observable<Posts[]>{
    //     // make ajaxified request here !
    //     // use Http Service here !
    //   return  this.httpServObj
    //     .get('https://jsonplaceholder.typicode.com/posts').map(
    //         res => res.json()
    //     )
      
    // }

    // creating an Observable
    getPosts():Observable<Posts[]>{
        // make ajaxified request here !
        // use Http Service here !
     return  this.httpServObj
        .get('https://jsonplaceholder.typicode.com/posts')
        .map(
            (res) => res.json()           
        )      
    }

}