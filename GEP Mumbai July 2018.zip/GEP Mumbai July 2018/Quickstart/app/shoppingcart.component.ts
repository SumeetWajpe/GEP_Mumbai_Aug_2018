import { Component, Input } from "@angular/core";
import {Product} from './product.model'


@Component({
    selector:'shoppingcart',
    templateUrl:`./app/shoppingcart.template.html`,
    styles:[`
    input.ng-pristine.ng-invalid{
        background-color:lightblue;
    }
    input.ng-dirty.ng-invalid{
        border:2px solid red;
    }
    input.ng-dirty.ng-valid{
        background-color:lightgreen;
    }
    `]
})
export class ShoppingCartComponent{

    heading:string="Shopping Cart !";
    isActive:boolean = false;
    areAllHighlighted:boolean=true;
    areAllProductStyled:boolean=true;
    company:string="";
    productToBeSearched:string="";
    newProduct:Product = new Product();
      products:Product[] = [
        new Product('Laptop',40000,30,3,'https://rukminim1.flixcart.com/image/704/704/j431rbk0/computer/t/h/p/hp-notebook-original-imaev2zfjqfpf3ng.jpeg?q=70'),
        new Product('LED TV',50000,20,3,'http://www.lg.com/in/images/tvs/md05602497/gallery/Large-940x620.jpg'),
        new Product('Desktop',20000,40,3,'https://images-eu.ssl-images-amazon.com/images/I/41IjXCFmiRL._SL500_AC_SS350_.jpg'),
        new Product('Mobile',30000,50,3,'https://assets.mspcdn.net/t_c-desktop-normal,f_auto,q_auto,d_c:noimage.jpg/c/8808-62-4.jpg'),
        new Product('Camera',50000,100,3,'https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_left.png')
             ]; 
             ChangeHeadingHandler(){                 
                this.heading = "Flipkart !";
             }

             ChangeHeadingOnInput(evt:any){
                 
                this.heading = evt.target.value;
             }

             OnSubmitOfForm(theForm:any){
                 // add a new product here !
                 this.newProduct.ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg"
                 this.products.push(this.newProduct);
                 this.newProduct = new Product();
                 theForm.reset();// will make the form reset !
                 // post to server as well !
             }
}