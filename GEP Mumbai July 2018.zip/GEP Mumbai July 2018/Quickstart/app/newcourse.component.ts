import { Component } from "@angular/core";
import { CourseService } from "./course.service";


@Component({
    selector:'newcourse',
    template:`

    <div style="border:2px solid red;border-radius:10px;margin:10px;padding:10px;">

    <h1> Courses </h1>

    <b> New Course : </b> <input type="text" [(ngModel)]="theInputCourse" />

    <input type="button" value="Add Course>>" (click)="AddNewCourse()" />

    <input type="button" value="Get Random Course !" (click)="GetRandomCourse()" />

    {{returnedCourse}}

    </div>

     `,providers:[CourseService]
})
export class NewCourseComponent{

    returnedCourse:string="";
    theInputCourse:string="";
    //DI
    constructor(private servObj:CourseService){
            console.log(this.servObj.getRandomCourse())
    }

    GetRandomCourse(){
            this.returnedCourse = this.servObj.getRandomCourse();
    }

    AddNewCourse(){
        this.servObj.addNewCourse(this.theInputCourse);
    }
   }