import { Component } from '@angular/core';
import {Course} from './course.model';
@Component({
  selector: 'my-app',
  template:`

  <a routerLink="/posts" class="btn btn-primary">Posts</a>
  <a routerLink="/cart" class="btn btn-primary">ShoppingCart</a>

  <router-outlet></router-outlet>
  
  `
//template:'<newcourse></newcourse><newcourse></newcourse>'
 // templateUrl:`./app/app.template.html`
 //template:`<shoppingcart></shoppingcart>`  
  ,styleUrls:[`./app/course.style.css`]
  //   template: `<course name="ReactJS"></course>
//   <course name="NodeJS"></course>
//   <course name="Backbone"></course>
//   <course></course>
//  `,
})
export class AppComponent  {
  imageUrl:string="https://cdn-images-1.medium.com/max/588/1*15CYVZdpsxir8KLdxEZytg.png"
  courses:Course[] = [
    new Course("React",'3 Days'),
    new Course("Redux",'2 Days'),
    new Course("Node",'3 Days')]
  }
