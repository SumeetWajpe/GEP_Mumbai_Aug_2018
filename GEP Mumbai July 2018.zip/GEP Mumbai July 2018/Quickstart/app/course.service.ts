export class CourseService{
    listOfCourses:string[]=['React','Angular','Node'];
    getAllCourses():string[]{
        return this.listOfCourses;
    }
    addNewCourse(newCourse:string){
        this.listOfCourses.push(newCourse);
    }
    getRandomCourse():string{
        return this.listOfCourses[Math.floor(Math.random() * this.listOfCourses.length)]
    }

}