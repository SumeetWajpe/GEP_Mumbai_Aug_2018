import { Component } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Posts } from "./posts.model";

@Component({
    selector:'post-detail',
    template:`<h1>Post Details for {{postId}} </h1>

    <b> Body : </b> {{specificPost.body}}
    `
})
export class PostDetailsComponent{
    postId:number;
    specificPost:Posts;
    allPosts:Posts[] = [];
   constructor(private currRoute:ActivatedRoute){
            var postId = this.currRoute.params.subscribe(
                (p)=>{
                            this.postId = (p["id"]);
                  this.allPosts = JSON.parse(localStorage["posts"]);
                 this.specificPost = this.allPosts.find(
                     (thePost:Posts)=>{
                         return thePost.id ==  this.postId
                     }
                 )
                }
            )
   }
}