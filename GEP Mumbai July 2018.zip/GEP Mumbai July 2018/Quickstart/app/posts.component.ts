import { Component } from "@angular/core";
import { PostsService } from "./posts.service";
import { Observable } from 'rxjs/Rx';
import { Posts } from "./posts.model";


@Component({
    selector:'posts',
    template:`<h1> Posts </h1>
    <ul>
        <li *ngFor="let p of allposts" postStyle bgcolor="lightgreen">
       <a routerLink="/post/{{p.id}}"> {{p.title}} </a>
        </li>
    </ul>
   `,
   providers:[PostsService]
})
export class PostsComponent{

    allposts:Posts=[];
    // srcArr:number[] = [1,2,3,4,5];
    // private myArr:Observable<number> = Observable.from(this.srcArr) 

    // using callbacks
    // constructor(private postsServObj:PostsService){
    //         this.postsServObj.getPosts((resp:any)=>{
    //                 console.log('within component');
    //                 this.allposts = resp;
    //         });
    // }


// using promises
    // constructor(private postsServObj:PostsService){
    //  let aPromise =   this.postsServObj.getPosts();
    //  aPromise.then(
    //      (responseFromService)=>{
    //          this.allposts =responseFromService.json();
    //      },
    //      (err)=>{
    //          console.log('rejected')
    //      }
    //  )
  //}

  //using Observables
    constructor(private postsServObj:PostsService){  
            this.postsServObj.getPosts().subscribe(
                res => {
                    this.allposts = res;
                    localStorage["posts"] = JSON.stringify(res);
                }
            )            
    }
}