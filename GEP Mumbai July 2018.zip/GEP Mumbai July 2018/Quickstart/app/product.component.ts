
import {Component,Input} from '@angular/core'
import { Product } from './product.model';


@Component({
selector:`product`,
templateUrl:`./app/product.template.html`,
styleUrls:['./app/product.styles.css']
})
export class ProductComponent{
     @Input()   prodDetails=new Product();   
     classToBeApplied:string = "ProductStyle";
    @Input() isHighlighted:boolean=true;
    @Input() isProductStyled:boolean=true; 
    isFree:boolean=false;    
    
}